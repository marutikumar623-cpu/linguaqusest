import os, sqlite3
from functools import wraps
from flask import Flask, jsonify, request, session, render_template
from werkzeug.security import generate_password_hash, check_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, 'linguaquest.db')
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'change-this-in-production')
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'


def db():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with db() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            grade TEXT, marks TEXT, language TEXT, country TEXT,
            state_json TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            rating INTEGER NOT NULL,
            message TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )''')


def public_user(row):
    return {
        'id': row['id'], 'name': row['name'], 'email': row['email'],
        'grade': row['grade'] or '', 'marks': row['marks'] or '',
        'language': row['language'] or '', 'country': row['country'] or ''
    }


def current_user():
    uid = session.get('user_id')
    if not uid: return None
    with db() as c:
        return c.execute('SELECT * FROM users WHERE id=?', (uid,)).fetchone()

@app.get('/')
def index():
    return render_template('index.html')

@app.post('/api/register')
def register():
    data = request.get_json(silent=True) or {}
    name = str(data.get('name','')).strip()
    email = str(data.get('email','')).strip().lower()
    password = str(data.get('password',''))
    grade = str(data.get('grade','')).strip()
    marks = str(data.get('marks','')).strip()
    language = str(data.get('language','')).strip()
    country = str(data.get('country','')).strip()
    if len(name) < 2: return jsonify(error='Please enter your name.'), 400
    if '@' not in email or '.' not in email: return jsonify(error='Please enter a valid email.'), 400
    if len(password) < 6: return jsonify(error='Password must be at least 6 characters.'), 400
    if not grade: return jsonify(error='Please select your grade / class.'), 400
    if marks and (not marks.replace('.','',1).isdigit() or float(marks)<0 or float(marks)>100): return jsonify(error='Marks must be between 0 and 100.'), 400
    if not language: return jsonify(error='Please select a preferred language.'), 400
    if len(country) < 2: return jsonify(error='Please enter your country.'), 400
    try:
        with db() as c:
            cur = c.execute('''INSERT INTO users(name,email,password_hash,grade,marks,language,country)
                VALUES(?,?,?,?,?,?,?)''', (name,email,generate_password_hash(password),grade,marks,language,country))
            uid = cur.lastrowid
            row = c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
    except sqlite3.IntegrityError:
        return jsonify(error='This email is already registered.'), 409
    session.clear(); session['user_id'] = uid; session.permanent = True
    return jsonify(user=public_user(row))

@app.post('/api/login')
def login():
    data=request.get_json(silent=True) or {}
    email=str(data.get('email','')).strip().lower(); password=str(data.get('password',''))
    with db() as c: row=c.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
    if not row or not check_password_hash(row['password_hash'], password):
        return jsonify(error='Email or password is incorrect.'), 401
    session.clear(); session['user_id']=row['id']; session.permanent=True
    return jsonify(user=public_user(row))

@app.get('/api/me')
def me():
    row=current_user()
    return jsonify(authenticated=bool(row), user=public_user(row) if row else None)

@app.post('/api/logout')
def logout():
    session.clear(); return jsonify(ok=True)

@app.get('/api/state')
def get_state():
    row=current_user()
    if not row: return jsonify(error='Not logged in.'), 401
    import json
    try: state=json.loads(row['state_json'] or '{}')
    except Exception: state={}
    return jsonify(user=public_user(row), state=state)

@app.put('/api/state')
def put_state():
    row=current_user()
    if not row: return jsonify(error='Not logged in.'), 401
    import json
    data=request.get_json(silent=True) or {}
    state=data.get('state')
    if not isinstance(state, dict): return jsonify(error='Invalid state.'), 400
    # Only store LinguaQuest keys; cap each value to keep the database reasonable.
    clean={str(k):str(v)[:200000] for k,v in state.items() if str(k).startswith('linguaquest_')}
    with db() as c:
        c.execute('UPDATE users SET state_json=?, updated_at=CURRENT_TIMESTAMP WHERE id=?',(json.dumps(clean,separators=(',',':')),row['id']))
    return jsonify(ok=True)


def gemini_answer(prompt):
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured on the server.")
    from google import genai
    client = genai.Client(api_key=api_key)
    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=prompt,
    )
    return (response.text or "").strip()


@app.post("/api/ai/ask")
def ai_ask():
    row = current_user()
    if not row:
        return jsonify(error="Please log in first."), 401
    data = request.get_json(silent=True) or {}
    question = str(data.get("question", "")).strip()
    mode = str(data.get("mode", "general")).strip().lower()
    if not question:
        return jsonify(error="Please enter a question."), 400
    if len(question) > 8000:
        return jsonify(error="Please keep the question under 8,000 characters."), 400
    modes = {
        "assignment": "Help with the assignment by explaining the idea clearly, then give a step-by-step solution or structured approach. Teach rather than simply dumping an answer.",
        "topic": "Explain the difficult topic from basics to a clear understanding. Use simple student-friendly language, examples, and a short recap.",
        "math": "Solve the mathematics problem step by step. Show the formula or rule, substitute values carefully, explain each step, and finish with the final answer. If the problem is ambiguous, say what is missing.",
        "general": "Act as a patient student learning assistant. Give accurate, age-appropriate explanations and encourage the student to understand the method."
    }
    instruction = modes.get(mode, modes["general"])
    prompt = "You are LinguaQuest AI, a student learning assistant.\n" + instruction + "\n\nStudent question:\n" + question + "\n\nKeep the response organized with headings or numbered steps when useful. Do not claim to have checked a source you did not check. If the student asks for a final assignment answer, include the reasoning so they can learn from it."
    try:
        answer = gemini_answer(prompt)
        return jsonify(answer=answer, model="gemini-2.5-flash")
    except Exception:
        return jsonify(error="AI assistant is temporarily unavailable. Check the server API key and try again."), 503


@app.post("/api/feedback")
def submit_feedback():
    row = current_user()
    if not row:
        return jsonify(error="Please log in first."), 401
    data = request.get_json(silent=True) or {}
    try:
        rating = int(data.get("rating", 0))
    except Exception:
        rating = 0
    message = str(data.get("message", "")).strip()
    if rating < 1 or rating > 5:
        return jsonify(error="Please choose a rating from 1 to 5."), 400
    if not message:
        return jsonify(error="Please enter your feedback."), 400
    if len(message) > 2000:
        return jsonify(error="Please keep feedback under 2,000 characters."), 400
    with db() as c:
        c.execute("INSERT INTO feedback(user_id,rating,message) VALUES(?,?,?)", (row["id"], rating, message))
    return jsonify(ok=True)

init_db()

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
